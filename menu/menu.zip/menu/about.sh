#!/bin/bash
clear
echo -e "==========================" | lolcat
echo -e "LUNATIC BACKEND VPN SCRIPT" | lolcat
echo -e "==========================" | lolcat
echo -e "===========================" | lolcat
echo -e "HARGA SCRIPT VPN PREMIUM" | lolcat
echo -e "===========================" | lolcat
echo -e "     \e[33;1mSCRIPT BULANAN\e[0m"
echo -e "===========================" | lolcat
echo -e "\e[37;1m 1 bulan 1 ip : 10k"
echo -e "\e[37;1m 2 bulan 1 ip : 20k"
echo -e "\e[37;1m 3 bulan 1 ip : 30k"
echo -e "===========================" | lolcat
echo -e "    \e[33;1mSCRIPT LIFETIME\e[0m"
echo -e "===========================" | lolcat
echo -e "\e[37;1m Lifetime 1 ip : 25k"
echo -e "\e[37;1m Lifetime 2 ip : 30k"
echo -e "\e[37;1m Lifetime 3 ip : 40k"
echo -e "\e[37;1m Lifetime 4 ip : 55k"
echo -e "\e[37;1m Lifetime 5 ip : 70k"
echo -e "===========================" | lolcat
echo -e "    \e[33;1mSCRIPT UNLIMITED\e[0m"
echo -e "===========================" | lolcat
echo -e "\e[37;1m Unlimited ip : 1 tahun : 150k"
echo -e "\e[37;1m Unlimited ip : 2 tahun : 200k"
echo -e "\e[92;1mBENEFIT:\e[0m"
echo -e "\e[35;1m Di Kasih Akses Daftar Ip\e[0m"
echo -e "\e[35;1m Bisa di sewakan\e[0m"
echo -e "===========================" | lolcat
echo -e "  \e[33;1mSCRIPT OPEN SOURCE\e[0m"
echo -e "===========================" | lolcat
echo -e "\e[37;1m Sc Open Source: 300k"
echo -e "\e[92;1mBENEFIT:\e[0m"
echo -e "\e[35;1m Full Akses script\e[0m"
echo -e "\e[35;1m Bebas Edit² Script\e[0m"
echo -e "\e[35;1m Script jadi hak Milik\e[0m"
echo -e "\e[35;1m Script Full Atas namamu\e[0m"
echo -e "===========================" | lolcat
echo ""
read -p " GO BACK "
menu
