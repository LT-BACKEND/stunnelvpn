clear
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
plain='\033[0m'
blue='\033[0;34m'
ungu='\033[0;35m'
Green="\033[32m"
Red="\033[31m"
WhiteB="\e[5;37m"
BlueCyan="\e[5;36m"
Green_background="\033[42;37m"
Red_background="\033[41;37m"
Suffix="\033[0m"

echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[44;97;1m          BACKUP LIBEV             \e[0m"
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[37;1m [01] • BACKUP VPS DATA \e[0m"
echo -e "\e[37;1m [02] • RESTOR VPS DATA \e[0m"
echo -e "\e[37;1m [03] • START           \e[0m"
echo -e "\e[37;1m [04] • SET LIMIT SPEED \e[0m"
echo -e "\e[37;1m [05] • AUTOBACKUP VPS  \e[0m"
echo -e "\e[31;1m [00] • GO BACK         \e[0m"
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\e[44;91;1m        LUNATIC TUNNELING          \e[0m"
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e ""
read -p " Just Input :  "  bro

if [ $bro = 1 ] || [ $bro = 1 ]
then
figlet "backup" | lolcat
mbackup
echo -e "\e[33;1m┌─────────────────────────────────────────────────┐\e[0m"
echo -e "\e[33;1m│\e[44;97;1m            • LUNATIC TUNNELING •              \e[0m"             
echo -e "\e[33;1m└─────────────────────────────────────────────────┘\e[0m"
fi

if [ $bro = 2 ] || [ $bro = 2 ]
then
figlet "Restore" | lolcat
mrestore
echo -e "\e[33;1m┌─────────────────────────────────────────────────┐\e[0m"
echo -e "\e[33;1m│\e[44;97;1m            • LUNATIC TUNNELING •              \e[0m"             
echo -e "\e[33;1m└─────────────────────────────────────────────────┘\e[0m"
fi
if [ $bro = 3 ] || [ $bro = 3 ]
then
figlet "strt"
mstrt
echo -e "\e[33;1m┌─────────────────────────────────────────────────┐\e[0m"
echo -e "\e[33;1m│\e[44;97;1m            • LUNATIC TUNNELING •              \e[0m"             
echo -e "\e[33;1m└─────────────────────────────────────────────────┘\e[0m"
fi
if [ $bro = 4 ] || [ $bro = 4 ]
then
mlimitspeed
echo -e "\e[33;1m┌─────────────────────────────────────────────────┐\e[0m"
echo -e "\e[33;1m│\e[44;97;1m            • LUNATIC TUNNELING •              \e[0m"             
echo -e "\e[33;1m└─────────────────────────────────────────────────┘\e[0m"
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
mautobackup
echo -e "\e[33;1m┌─────────────────────────────────────────────────┐\e[0m"
echo -e "\e[33;1m│\e[44;97;1m            • LUNATIC TUNNELING •              \e[0m"             
echo -e "\e[33;1m└─────────────────────────────────────────────────┘\e[0m"
fi

if [ $bro = 00 ] || [ $bro = 00 ]
then
dashboard
fi
